package com.example.visualphysics10.physics;

public class MathPart {
}
