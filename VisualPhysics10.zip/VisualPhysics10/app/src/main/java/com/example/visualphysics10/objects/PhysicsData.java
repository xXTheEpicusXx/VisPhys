package com.example.visualphysics10.objects;

public class PhysicsData {
    public static double radius;
    public static double speed;
    public static double distance;
    public static double acc;
    public static double mass1;
    public static double mass2;

    public static double getRadius() {
        return radius;
    }

    public static void setRadius(double radius) {
        PhysicsData.radius = radius;
    }

    public static double getSpeed() {
        return speed;
    }

    public static void setSpeed(double speed) {
        PhysicsData.speed = speed;
    }

    public static double getDistance() {
        return distance;
    }

    public static void setDistance(double distance) {
        PhysicsData.distance = distance;
    }

    public static double getAcc() {
        return acc;
    }

    public static void setAcc(double acc1) {
        acc = acc1;
    }

    public static double getMass1() {
        return mass1;
    }

    public static void setMass1(double mass1) {
        PhysicsData.mass1 = mass1;
    }

    public static double getMass2() {
        return mass2;
    }

    public static void setMass2(double mass2) {
        PhysicsData.mass2 = mass2;
    }


}
